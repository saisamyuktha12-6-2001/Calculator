# GUI-based Calculator using Tkinter

import tkinter as tk
from tkinter import messagebox

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Calculator")

        self.num1_label = tk.Label(root, text="Enter first number:")
        self.num1_label.pack()
        self.num1_entry = tk.Entry(root)
        self.num1_entry.pack()

        self.num2_label = tk.Label(root, text="Enter second number:")
        self.num2_label.pack()
        self.num2_entry = tk.Entry(root)
        self.num2_entry.pack()

        self.operation_label = tk.Label(root, text="Select operation:")
        self.operation_label.pack()

        self.add_button = tk.Button(root, text="Add", command=self.add)
        self.add_button.pack()

        self.subtract_button = tk.Button(root, text="Subtract", command=self.subtract)
        self.subtract_button.pack()

        self.multiply_button = tk.Button(root, text="Multiply", command=self.multiply)
        self.multiply_button.pack()

        self.divide_button = tk.Button(root, text="Divide", command=self.divide)
        self.divide_button.pack()

        self.result_label = tk.Label(root, text="Result:")
        self.result_label.pack()
        self.result = tk.Label(root, text="")
        self.result.pack()

    def get_numbers(self):
        try:
            num1 = float(self.num1_entry.get())
            num2 = float(self.num2_entry.get())
            return num1, num2
        except ValueError:
            messagebox.showerror("Error", "Invalid input. Please enter numeric values.")
            return None, None

    def add(self):
        num1, num2 = self.get_numbers()
        if num1 is not None and num2 is not None:
            result = num1 + num2
            self.result.config(text=f"{result}")

    def subtract(self):
        num1, num2 = self.get_numbers()
        if num1 is not None and num2 is not None:
            result = num1 - num2
            self.result.config(text=f"{result}")

    def multiply(self):
        num1, num2 = self.get_numbers()
        if num1 is not None and num2 is not None:
            result = num1 * num2
            self.result.config(text=f"{result}")

    def divide(self):
        num1, num2 = self.get_numbers()
        if num1 is not None and num2 is not None:
            if num2 == 0:
                messagebox.showerror("Error", "Division by zero is not allowed.")
            else:
                result = num1 / num2
                self.result.config(text=f"{result}")

if __name__ == "__main__":
    root = tk.Tk()
    calculator = Calculator(root)
    root.mainloop()
